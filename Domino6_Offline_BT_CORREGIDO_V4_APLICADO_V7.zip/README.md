# Domino6 Offline BT - V7

Base: Domino6_Offline_BT_CORREGIDO_V4_APLICADO_V6

Correcciones V7 basadas en la foto de referencia del usuario:
- El marcador queda junto al encabezado "Mesa", desplazado hacia la izquierda respecto a su posición anterior.
- Ficha normal sobre la cadena: horizontal.
- Doble sobre la cadena: vertical.
- La ficha inicial permanece fija en el centro.
- Al llegar a un extremo, se colocan exactamente 2 fichas en vertical antes de continuar horizontalmente en sentido contrario.
- En esas dos posiciones de giro, la ficha se dibuja vertical aunque no sea doble, para reproducir el recorrido de la referencia.
- Se conserva el icono doble seis blanco sobre fondo verde y el resto de la lógica del proyecto.
