# Domino6 Offline BT - V8

Base: Domino6_Offline_BT_CORREGIDO_V4_APLICADO_V7.zip

Cambios V8:
- Mantiene el icono doble seis blanco sobre fondo verde.
- Marcador de puntos colocado junto a la palabra "Mesa" sin taparla.
- Las fichas normales de la mesa son horizontales y sus valores se leen horizontalmente.
- Los dobles son verticales.
- La cadena se dibuja pegada, sin huecos innecesarios entre fichas.
- En los giros se colocan dos fichas verticales antes de cambiar de sentido.
- Se respeta la continuidad de valores en los extremos: el valor que conecta queda junto al mismo valor.
- En partida contra la computadora aparece "Nueva mano" al terminar.
- Se conserva la puntuación acumulada y la regla de apertura de la mano siguiente.
