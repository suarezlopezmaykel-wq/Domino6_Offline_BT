# Domino6 Offline BT

Proyecto nuevo e independiente para Dominó 6.

## Requisitos incorporados

- Doble-seis: 28 fichas.
- 7 fichas por jugador.
- Juego contra computadora.
- Bluetooth para 2, 3 y 4 jugadores.
- Sin Internet durante la partida.
- Si se puede jugar, hay que jugar; si no, se pasa.
- Tranca: gana quien tenga menos puntos en las fichas restantes.
- Empate: 0,5 puntos para cada jugador empatado.
- Victoria normal: 1 punto.
- Puntuación acumulada durante la sesión y privada para cada jugador.
- Al volver al menú se reinicia la puntuación.
- Primera mano Bluetooth: abre el anfitrión.
- Nueva mano sin desconectar Bluetooth.
- Mano siguiente: abre el ganador; en empate, conserva la apertura el abridor si está empatado; si no, se elige aleatoriamente entre los empatados.
- Si una ficha puede ir a ambos extremos, se pregunta Izquierda/Derecha.
- Las fichas jugadas permanecen visibles en la mesa.
- Tablero desplazable.
- Sonido propio al comenzar una mano.
- Sonido propio solamente cuando una ficha válida es aceptada.
- Sonido propio al terminar la mano, incluida la tranca.
- Sonidos generados localmente: no se necesitan archivos de audio ni Internet.
- Interfaz de mesa verde, fichas marfil y puntos negros.

## Compilación

GitHub Actions: Java 17 + Gradle 8.9 + Android Gradle Plugin 8.7.3.
