# Domino6 Offline BT – V16

Continuación directa de V14. No reinicia el proyecto.

Cambios de esta versión:
- Los dobles siguen la orientación del tramo: horizontales en tramos horizontales y verticales en subidas/bajadas.
- La mesa usa un único motor de recorrido para ambos lados: cada giro utiliza exactamente dos fichas verticales antes de cambiar el sentido horizontal.
- Las fichas permanecen pegadas, sin superposición.
- La orientación visual conserva el extremo de conexión: el número igual queda físicamente unido al número igual.
- La numeración/puntos de las fichas verticales y horizontales mantiene sus patrones correspondientes.
- En modo computadora, el marcador muestra simultáneamente la puntuación del jugador y de la CPU, por ejemplo `🏆 Tú: 0.0   CPU: 1.0`.
- La computadora continúa jugando automáticamente cuando le corresponde iniciar una nueva mano.
- Se conserva el sonido de ficha golpeando la mesa introducido en V14.


V16: corrected BoardView left-branch boundary crash on first tile.
