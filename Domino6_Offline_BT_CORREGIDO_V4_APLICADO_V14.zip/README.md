# Domino6 Offline BT - V13

Base: Domino6_Offline_BT_CORREGIDO_V4_APLICADO_V11.zip

Cambios V13:
- Mantiene el icono doble seis blanco sobre fondo verde.
- El marcador queda en un encabezado horizontal independiente de la palabra "Mesa", sin superposición.
- Toda ficha horizontal de la mesa conserva sus valores de izquierda a derecha.
- La representación de puntos de una ficha horizontal sigue orientación horizontal; la de una ficha vertical sigue orientación vertical.
- Se corrige la representación de 5 y 6: cada valor muestra siempre el número correcto de puntos.
- Los dobles de la mesa se muestran horizontales; ya no se convierten automáticamente en verticales.
- Las fichas se colocan pegadas, sin separación innecesaria, evitando el solapamiento en los tramos de cadena.
- Los únicos elementos verticales del recorrido son los usados para los tramos de subida y bajada.
- La lógica de colocación queda protegida para que una ficha solo pueda conectarse por un valor igual al extremo abierto.
- Se conserva el orden real de los valores almacenados de cada ficha al dibujarla; no se vuelve a invertir indebidamente la ficha de la izquierda.
- En partida contra la computadora, al iniciar una nueva mano, si la computadora es quien abre, realiza automáticamente su primera jugada.
- Se conserva la puntuación acumulada, la regla de apertura de la mano siguiente y el funcionamiento Bluetooth.


Correcciones V13: marcador sin "Mesa"; patrones de puntos orientados por eje; dobles horizontales; turno automático de computadora al iniciar/nueva mano; colocación sin romper coincidencias.
