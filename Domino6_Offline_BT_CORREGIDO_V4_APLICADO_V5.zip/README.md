# Domino6 Offline BT

Proyecto nuevo e independiente para Dominó 6.

## Requisitos incorporados

- Doble-seis: 28 fichas.
- 7 fichas por jugador.
- Juego contra computadora.
- Bluetooth para 2, 3 y 4 jugadores.
- Sin Internet durante la partida.
- Si se puede jugar, hay que jugar; si no, se pasa.
- Tranca: gana quien tenga menos puntos en las fichas restantes.
- Empate: 0,5 puntos para cada jugador empatado.
- Victoria normal: 1 punto.
- Puntuación acumulada durante la sesión y privada para cada jugador.
- Al volver al menú se reinicia la puntuación.
- Primera mano Bluetooth: abre el anfitrión.
- Nueva mano sin desconectar Bluetooth.
- Mano siguiente: abre el ganador; en empate, conserva la apertura el abridor si está empatado; si no, se elige aleatoriamente entre los empatados.
- Si una ficha puede ir a ambos extremos, se pregunta Izquierda/Derecha.
- Las fichas jugadas permanecen visibles en la mesa.
- Tablero desplazable.
- Sonido propio al comenzar una mano.
- Sonido propio solamente cuando una ficha válida es aceptada.
- Sonido propio al terminar la mano, incluida la tranca.
- Sonidos generados localmente: no se necesitan archivos de audio ni Internet.
- Interfaz de mesa verde, fichas marfil y puntos negros.

## Compilación

GitHub Actions: Java 17 + Gradle 8.9 + Android Gradle Plugin 8.7.3.


## Corrección de interfaz
- En la mesa, las fichas normales se muestran horizontales y solamente los dobles se muestran verticales.
- El marcador acumulado propio aparece en la esquina superior derecha y se conserva durante la sesión hasta salir al menú.


## Distribución visual aplicada en V4 corregida
- Las fichas de la mano se centran horizontalmente cuando caben en pantalla, con separación uniforme.
- La ficha inicial de la mesa permanece exactamente en el centro y no se desplaza.
- Las fichas normales de la mesa son horizontales; los dobles permanecen verticales.
- Las fichas de mesa son más pequeñas que las fichas de la mano.
- Desde la ficha central, la rama derecha avanza hacia la derecha; al llegar a su límite baja y cambia de sentido.
- Desde la ficha central, la rama izquierda avanza hacia la izquierda; al llegar a su límite sube y cambia de sentido.
- Se reserva espacio independiente para cada ficha para evitar solapamientos.
